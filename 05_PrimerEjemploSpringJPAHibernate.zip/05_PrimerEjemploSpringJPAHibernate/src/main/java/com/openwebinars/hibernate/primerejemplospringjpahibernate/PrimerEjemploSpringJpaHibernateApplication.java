package com.openwebinars.hibernate.primerejemplospringjpahibernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimerEjemploSpringJpaHibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimerEjemploSpringJpaHibernateApplication.class, args);
	}
}
